from tkinter import *
from tkinter import ttk
from tkinter import messagebox
import sqlite3

class Bill:
    def __init__(self, root, conn):
        self.root = root
        self.root.title("BILL GENERATION")
        self.root.geometry("1295x550+230+220")
        self.conn = conn

        # Title Section
        lb_title = Label(self.root, text="BILL GENERATION", font=("times new roman", 12, "bold"), bg="lightgrey", fg="black", bd=4, relief=RIDGE)
        lb_title.place(x=0, y=0, relwidth=1)

        # PDF Preview Section
        pdf_preview_frame = Frame(self.root, bd=2, relief=RIDGE)
        pdf_preview_frame.place(x=500, y=50, width=690, height=670)  # Increased width to 700

        lbl_pdf_preview = Label(pdf_preview_frame, text="PDF Preview", font=("times new roman", 10, "bold"))
        lbl_pdf_preview.grid(row=0, column=0, columnspan=2, pady=5)

        btn_download_pdf = Button(pdf_preview_frame, text="Download PDF", font=("times new roman", 10))
        btn_download_pdf.grid(row=1, column=0, columnspan=2, pady=10)

        # Add scrollbar for preview section
        scrollbar_preview = Scrollbar(pdf_preview_frame, orient=VERTICAL)
        scrollbar_preview.grid(row=0, column=1000, rowspan=100)  # Span two rows to fill height

        # Search Bar Section
        search_frame = Frame(self.root, bd=2, relief=RIDGE)
        search_frame.place(x=10, y=50, width=480, height=50)

        lb_search = Label(search_frame, text="Search By:", font=("times new roman", 10))
        lb_search.grid(row=0, column=0, padx=5, pady=5)

        self.combo_search = ttk.Combobox(search_frame, state="readonly", width=15)
        self.combo_search["values"] = ("Guest Ref", "Room Number")
        self.combo_search.current(0)
        self.combo_search.grid(row=0, column=1, padx=5, pady=5)

        self.entry_search = Entry(search_frame, bd=2, relief=GROOVE, width=20)
        self.entry_search.grid(row=0, column=2, padx=5, pady=5)

        btn_search = Button(search_frame, text="Search", command=self.search_guest, font=("times new roman", 10), bg="black", fg="gold", bd=3, relief=RAISED, width=10)
        btn_search.grid(row=0, column=3, padx=5, pady=5)

        # Guest Details Section
        guest_details_frame = Frame(self.root, bd=2, relief=RIDGE)
        guest_details_frame.place(x=10, y=110, width=480, height=200)

        lbl_guest_details = Label(guest_details_frame, text="Guest Details", font=("times new roman", 10, "bold"))
        lbl_guest_details.grid(row=0, column=0, columnspan=2, pady=5)

        # Auto-filled Guest Details
        labels = ["Guest Ref:", "Name:", "Unit FMN:", "Contact:", "Reference:"]
        guest_details = ["Guest1", "John Doe", "Unit1", "1234567890", "Ref123"]

        for i, (label_text, detail) in enumerate(zip(labels, guest_details), start=1):
            lbl = Label(guest_details_frame, text=label_text, font=("times new roman", 10))
            lbl.grid(row=i, column=0, padx=5, pady=5, sticky="w")

            lbl_detail = Label(guest_details_frame, text=detail, font=("times new roman", 10))
            lbl_detail.grid(row=i, column=1, padx=5, pady=5, sticky="w")

        # User Input Section
        user_input_frame = Frame(self.root, bd=2, relief=RIDGE)
        user_input_frame.place(x=10, y=320, width=480, height=400)

        labels = [
            "Room Rent:", "Rebate:", "Late Check In:", "Not Occupied:", "Less than 24 Hours(80%):",
            "Less than 24 Hours to 48 Hours(40%):", "Less than 48 Hours to 96 Hours:", "Breakfast:",
            "Lunch:", "Dinner:", "Brunch:", "Extra Messing:", "Cascade:", "Chips & Biscuit:",
            "Soft Drink & Water Bottle:", "Bar:", "Live Kitchen:", "Breakages:", "Laundry:",
            "Pets:", "Electric Bill:", "Extra Mattress:", "Cancellation Charges:"
        ]

        for i, label_text in enumerate(labels, start=len(labels)+2):
            lbl = Label(user_input_frame, text=label_text, font=("times new roman", 10))
            lbl.grid(row=i, column=0, padx=5, pady=5, sticky="w")

            entry = Entry(user_input_frame, bd=2, relief=GROOVE, width=10)
            entry.grid(row=i, column=1, padx=5, pady=5, sticky="w")

        # Add scrollbar for user input section
        scrollbar_user_input = Scrollbar(user_input_frame, orient=VERTICAL)
        scrollbar_user_input.grid(row=2, column=2, rowspan=2, sticky="ns")  # Span two rows to fill height

    def search_guest(self):
        # Implement your search logic here
        pass

if __name__ == "__main__":
    try:
        conn = sqlite3.connect("guest_info.db")
        root = Tk()
        obj = Bill(root, conn)
        root.mainloop()
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {str(e)}")
    finally:
        conn.close()
