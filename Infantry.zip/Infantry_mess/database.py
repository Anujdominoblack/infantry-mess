import sqlite3

class Database:
    def __init__(self, db_file):
        self.conn = self.create_connection(db_file)
        self.create_tables()

    def create_connection(self, db_file):
        conn = None
        try:
            conn = sqlite3.connect(db_file)
            print("Connection to SQLite DB successful")
            return conn
        except sqlite3.Error as e:
            print(f"Error connecting to SQLite DB: {e}")
            return None

    def create_tables(self):
        if self.conn is not None:
            try:
                cursor = self.conn.cursor()
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS guest_info (
                        guest_ref INTEGER PRIMARY KEY,
                        name TEXT,
                        unit_fmn TEXT,
                        contact TEXT,
                        reference TEXT
                    )
                """)
                cursor.execute("""
                    CREATE TABLE IF NOT EXISTS bookings (
                        booking_id INTEGER PRIMARY KEY,
                        guest_ref INTEGER,
                        room_number INTEGER,
                        booking_date DATE,
                        departure_date DATE,
                        advance_payment TEXT,
                        advance_receipt_no TEXT,
                        advance_amount REAL,
                        FOREIGN KEY (guest_ref) REFERENCES guest_info(guest_ref)
                    )
                """)
                self.conn.commit()
                print("Tables created successfully")
            except sqlite3.Error as e:
                print(f"Error creating tables: {e}")
        else:
            print("Error: Database connection is not established")

    def add_guest(self, name, unit_fmn, contact, reference):
        try:
            cursor = self.conn.cursor()
            cursor.execute("""
                INSERT INTO guest_info (name, unit_fmn, contact, reference)
                VALUES (?, ?, ?, ?)
            """, (name, unit_fmn, contact, reference))
            self.conn.commit()
            print("Guest information added successfully")
            return cursor.lastrowid
        except sqlite3.Error as e:
            print(f"Error adding guest information: {e}")
            return None

    def add_booking(self, guest_ref, room_number, booking_date, departure_date, advance_payment, advance_receipt_no, advance_amount):
        try:
            cursor = self.conn.cursor()
            cursor.execute("""
                INSERT INTO bookings (guest_ref, room_number, booking_date, departure_date, advance_payment, advance_receipt_no, advance_amount)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (guest_ref, room_number, booking_date, departure_date, advance_payment, advance_receipt_no, advance_amount))
            self.conn.commit()
            print("Booking added successfully")
            return cursor.lastrowid
        except sqlite3.Error as e:
            print(f"Error adding booking: {e}")
            return None
