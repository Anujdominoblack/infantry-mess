import sqlite3
from tkinter import *
from tkinter import ttk, messagebox
from datetime import datetime

class Booking:
    def __init__(self, root, conn):
        self.root = root
        self.conn = conn
        self.root.title("BOOKING")
        self.root.geometry("1295x550+230+220")

        self.create_booking_table()
        self.selected_block = StringVar()
        self.advance_payment_date_var = StringVar()
        self.selected_room = StringVar()
        self.booking_date = None
        self.departure_date = None

        # Title Section
        lb_title = Label(self.root, text="GUEST BOOKING", font=("times new roman", 10, "bold", "italic"), bg="black", fg="gold", bd=4, relief=RIDGE)
        lb_title.pack(fill=X)

        # Label Frame
        labelframeleft = LabelFrame(self.root, bd=2, relief=RIDGE, text="Booking", font=("times new roman", 12, "bold", "italic"), padx=20, pady=20)
        labelframeleft.place(x=5, y=50, width=430, height=540)

        # Labels and Entry Widgets
        labels = [
            "Guest Ref:", "Block Name:", "Room Number:", "Booking Date:", "Departure Date:",
            "Advance Payment:"
        ]
        self.entry_widgets = []
        self.date_entry_widgets = []

        for i, label_text in enumerate(labels):
            lbl = Label(labelframeleft, text=label_text, font=("times new roman", 12), padx=5, pady=5)
            lbl.grid(row=i, column=0, sticky="w")

            if label_text == "Guest Ref:":
                guest_ref_entry = Entry(labelframeleft, font=("times new roman", 12), bd=2, relief=GROOVE)
                guest_ref_entry.grid(row=i, column=1, padx=10, pady=5, sticky="w")
                self.entry_widgets.append(guest_ref_entry)
            elif label_text == "Block Name:":
                block_options = ["Old", "Carippa", "Manekshaw"]
                block_dropdown = OptionMenu(labelframeleft, self.selected_block, *block_options, command=self.update_room_numbers)
                block_dropdown.config(width=15)
                block_dropdown.grid(row=i, column=1, padx=10, pady=5, sticky="w")
            elif label_text == "Room Number:":
                self.room_menu = OptionMenu(labelframeleft, self.selected_room, "", command=self.update_room_numbers)
                self.room_menu.config(width=15)
                self.room_menu.grid(row=i, column=1, padx=10, pady=5, sticky="w")
                self.entry_widgets.append(self.room_menu)
            elif label_text in ("Booking Date:", "Departure Date:"):
                entry_date = Entry(labelframeleft, width=12, font=("times new roman", 12, "bold"), bd=2, relief=GROOVE)
                entry_date.grid(row=i, column=1, padx=10, pady=5, sticky="w")
                self.entry_widgets.append(entry_date)

            elif label_text == "Advance Payment:":
                payment_options = ["Yes", "No"]
                payment_dropdown = OptionMenu(labelframeleft, self.advance_payment_date_var, *payment_options, command=self.toggle_advance_fields)
                payment_dropdown.config(width=10)
                payment_dropdown.grid(row=i, column=1, padx=10, pady=5, sticky="w")

        self.advance_payment_fields = []  # Remove redundant initialization

        # Advance Payment Fields (Hidden by Default)
        advance_labels = ["Advance Payment Date:", "Advance Payment Receipt No.:", "Advance Amount:"]
        for i, label_text in enumerate(advance_labels):
            lbl = Label(labelframeleft, text=label_text, font=("times new roman", 12), padx=5, pady=5)
            lbl.grid(row=len(labels) + i, column=0, sticky="w")
            entry = Entry(labelframeleft, font=("times new roman", 12), bd=2, relief=GROOVE, state="disabled")
            entry.grid(row=len(labels) + i, column=1, padx=10, pady=5, sticky="w")
            self.entry_widgets.append(entry)
            self.advance_payment_fields.append(entry)

        # Assign Button Frame
        assign_frame = Frame(labelframeleft, bd=2, relief=RIDGE)
        assign_frame.grid(row=len(labels) + len(advance_labels) + 2, columnspan=2, padx=0, pady=10)

        btn_assign = Button(assign_frame, text="Assign", font=("times new roman", 12), bg="black", fg="gold", bd=3, relief=RAISED, width=10, command=self.assign_room)
        btn_assign.grid(row=0, column=0, padx=5, pady=5)
        btn_Block = Button(assign_frame, text="Block", font=("times new roman", 12), bg="black", fg="gold", bd=3, relief=RAISED, width=10)
        btn_Block.grid(row=0, column=1, padx=5, pady=5)

        # Table Frame
        table_frame = LabelFrame(self.root, bd=2, relief=RIDGE, text="View Details And Search", font=("times new roman", 12, "bold", "italic"), padx=20, pady=20)
        table_frame.place(x=435, y=50, width=830, height=490)

        lbsearch = Label(table_frame, text="Search By: ", font=("times new roman", 12),bg="red",fg="white")
        lbsearch.grid(row=0, column=0, sticky=W,padx=2)

        self.combo_search=ttk.Combobox(table_frame,font=("arial",12,"bold"),width=24,state="readonly")
        self.combo_search["value"]=("Guest Ref","Block Name","Room Number")
        self.combo_search.current(0)
        self.combo_search.grid(row=0,column=1,padx=2)

        self.entrySearch = Entry(table_frame, font=("times new roman", 12), width=24)
        self.entrySearch.grid(row=0, column=2,padx=2)

        btn_search = Button(table_frame, text="Search",command=self.search_guest, font=("times new roman", 12), bg="black", fg="gold", bd=3, relief=RAISED, width=10)
        btn_search.grid(row=0, column=3, padx=1)

        btn_all = Button(table_frame, text="Show All", command=self.show_all_guests, font=("times new roman", 12), bg="black", fg="gold", bd=3, relief=RIDGE, width=10)
        btn_all.grid(row=0, column=4, padx=1)

        # Data table
        details_table=Frame(table_frame,bd=3,relief=RIDGE)
        details_table.place(x=0,y=50,width=800,height=350)

        scroll_x=ttk.Scrollbar(details_table,orient=HORIZONTAL)
        scroll_y=ttk.Scrollbar(details_table,orient=VERTICAL)

        self.Guest_Details_Table=ttk.Treeview(details_table,columns=("Guest Ref", "Name", "Block", "Room Number", "Booking Date", "Departure Date"),xscrollcommand=scroll_x.set,yscrollcommand=scroll_y.set)

        # Set anchor to center for all columns
        for column in ("Guest Ref", "Name", "Block", "Room Number", "Booking Date", "Departure Date"):
            self.Guest_Details_Table.heading(column, text=column, anchor="center")
            self.Guest_Details_Table.column(column, anchor="center")

        scroll_x.pack(side=BOTTOM,fill=X)
        scroll_y.pack(side=RIGHT,fill=Y)

        scroll_x.config(command=self.Guest_Details_Table.xview)
        scroll_y.config(command=self.Guest_Details_Table.yview)

        self.Guest_Details_Table["show"]="headings"

        self.Guest_Details_Table.column("Guest Ref",width=100)
        self.Guest_Details_Table.column("Name",width=100)
        self.Guest_Details_Table.column("Block",width=100)
        self.Guest_Details_Table.column("Room Number",width=100)
        self.Guest_Details_Table.column("Booking Date",width=100)
        self.Guest_Details_Table.column("Departure Date",width=100)
        self.Guest_Details_Table.pack(fill=BOTH,expand=1)

    def toggle_advance_fields(self, selected_option):
        if selected_option == "Yes":
            for entry in self.advance_payment_fields:
                entry.config(state="normal")
        else:
            for entry in self.advance_payment_fields:
                entry.delete(0, END)  # Clear the contents of the entry
                entry.config(state="disabled")

    def update_room_numbers(self, *args):
        selected_block = self.selected_block.get()
        if selected_block == "Old":
            available_rooms = [41, 42, 43, 44, 45, 46, 48]
        elif selected_block == "Carippa":
            available_rooms = list(range(1, 8)) + list(range(11, 18)) + list(range(21, 28)) + list(range(31, 38))
        elif selected_block == "Manekshaw":
            available_rooms = list(range(1, 21))
        else:
            available_rooms = []

        self.selected_room.set("")  # Clear the selection
        self.room_menu['menu'].delete(0, 'end')
        for room_number in available_rooms:
            self.room_menu['menu'].add_command(label=room_number, command=lambda value=room_number: self.selected_room.set(value))

    def assign_room(self):
        if len(self.entry_widgets) < 5:
            messagebox.showerror("Error", "Please fill in all the required fields.")
            return

        guest_ref = self.entry_widgets[0].get()
        block_name = self.selected_block.get()
        room_number = self.selected_room.get()

        # Retrieve booking and departure dates from the correct widgets
        booking_date_str = self.entry_widgets[4].get().strip()
        departure_date_str = self.entry_widgets[3].get().strip()

        advance_payment_status = self.advance_payment_date_var.get()

        if not booking_date_str or not departure_date_str:
            messagebox.showerror("Error", "Please fill in the Booking Date and Departure Date.")
            return

        expected_format = '%Y-%m-%d'  # Specify the expected date format
        try:
            booking_date = datetime.strptime(booking_date_str, expected_format).date()
            departure_date = datetime.strptime(departure_date_str, expected_format).date()
        except ValueError:
            messagebox.showerror("Error", f"Invalid date format. Please use {expected_format}.")
            return

        if booking_date >= departure_date:
            messagebox.showerror("Error", "Booking Date should be before the Departure Date.")
            return

        try:
            cursor = self.conn.cursor()
            cursor.execute("SELECT * FROM booking WHERE room_number = ? AND ((? >= booking_date AND ? < departure_date) OR (? >= booking_date AND ? < departure_date) OR (booking_date >= ? AND booking_date < ?))",
                        (room_number, booking_date, booking_date, departure_date, departure_date, booking_date, departure_date))
            existing_overlapping_booking = cursor.fetchone()

            if existing_overlapping_booking:
                messagebox.showerror("Error", "The selected room is already booked for the specified period.")
                return

            if advance_payment_status == "Yes":
                advance_payment_date_str = self.entry_widgets[5].get().strip()
                if not advance_payment_date_str:
                    messagebox.showerror("Error", "Please fill in the Advance Payment Date.")
                    return
                advance_payment_date = datetime.strptime(advance_payment_date_str, expected_format).date()
                if advance_payment_date > booking_date:
                    messagebox.showerror("Error", "Advance Payment Date should be before or same as Booking Date.")
                    return

                cursor.execute("INSERT INTO booking (guest_ref, block_name, room_number, booking_date, departure_date, advance_payment, advance_payment_date) VALUES (?, ?, ?, ?, ?, ?, ?)",
                            (guest_ref, block_name, room_number, booking_date.isoformat(), departure_date.isoformat(), advance_payment_status, advance_payment_date.isoformat()))
            else:
                cursor.execute("INSERT INTO booking (guest_ref, block_name, room_number, booking_date, departure_date, advance_payment) VALUES (?, ?, ?, ?, ?, ?)",
                            (guest_ref, block_name, room_number, booking_date.isoformat(), departure_date.isoformat(), advance_payment_status))

            self.conn.commit()
            messagebox.showinfo("Success", "Room assigned successfully")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

    def block_room(self):
        if len(self.entry_widgets) < 5:
            messagebox.showerror("Error", "Please fill in all the required fields.")
            return

        guest_ref = self.entry_widgets[0].get()
        block_name = self.selected_block.get()
        room_number = self.selected_room.get()

        # Retrieve booking and departure dates from the correct widgets
        booking_date_str = self.entry_widgets[4].get().strip()
        departure_date_str = self.entry_widgets[3].get().strip()

        advance_payment_status = self.advance_payment_date_var.get()

        if not booking_date_str or not departure_date_str:
            messagebox.showerror("Error", "Please fill in the Booking Date and Departure Date.")
            return

        expected_format = '%Y-%m-%d'  # Specify the expected date format
        try:
            booking_date = datetime.strptime(booking_date_str, expected_format).date()
            departure_date = datetime.strptime(departure_date_str, expected_format).date()
        except ValueError:
            messagebox.showerror("Error", f"Invalid date format. Please use {expected_format}.")
            return

        if booking_date >= departure_date:
            messagebox.showerror("Error", "Booking Date should be before the Departure Date.")
            return

        try:
            cursor = self.conn.cursor()
            cursor.execute("SELECT * FROM booking WHERE room_number = ? AND ((? >= booking_date AND ? < departure_date) OR (? >= booking_date AND ? < departure_date) OR (booking_date >= ? AND booking_date < ?))",
                        (room_number, booking_date, booking_date, departure_date, departure_date, booking_date, departure_date))
            existing_overlapping_booking = cursor.fetchone()

            if existing_overlapping_booking:
                messagebox.showerror("Error", "The selected room is already booked for the specified period.")
                return

            if advance_payment_status == "Yes":
                advance_payment_date_str = self.entry_widgets[5].get().strip()
                if not advance_payment_date_str:
                    messagebox.showerror("Error", "Please fill in the Advance Payment Date.")
                    return
                advance_payment_date = datetime.strptime(advance_payment_date_str, expected_format).date()
                if advance_payment_date > booking_date:
                    messagebox.showerror("Error", "Advance Payment Date should be before or same as Booking Date.")
                    return

                cursor.execute("INSERT INTO booking (guest_ref, block_name, room_number, booking_date, departure_date, advance_payment, advance_payment_date) VALUES (?, ?, ?, ?, ?, ?, ?)",
                            (guest_ref, block_name, room_number, booking_date.isoformat(), departure_date.isoformat(), advance_payment_status, advance_payment_date.isoformat()))
            else:
                cursor.execute("INSERT INTO booking (guest_ref, block_name, room_number, booking_date, departure_date, advance_payment) VALUES (?, ?, ?, ?, ?, ?)",
                            (guest_ref, block_name, room_number, booking_date.isoformat(), departure_date.isoformat(), advance_payment_status))

            self.conn.commit()
            messagebox.showinfo("Success", "Room blocked successfully")
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")
    def search_guest(self):
        search_by = self.combo_search.get()
        search_text = self.entrySearch.get()

        try:
            cursor = self.conn.cursor()
            if search_by == "Guest Ref":
                cursor.execute("SELECT b.guest_ref, g.name, b.block_name, b.room_number, b.booking_date, b.departure_date FROM booking b INNER JOIN guest_info g ON b.guest_ref = g.guest_ref WHERE b.guest_ref=?", (search_text,))
            elif search_by == "Block Name":
                cursor.execute("SELECT b.guest_ref, g.name, b.block_name, b.room_number, b.booking_date, b.departure_date FROM booking b INNER JOIN guest_info g ON b.guest_ref = g.guest_ref WHERE b.block_name=?", (search_text,))
            elif search_by == "Room Number":
                cursor.execute("SELECT b.guest_ref, g.name, b.block_name, b.room_number, b.booking_date, b.departure_date FROM booking b INNER JOIN guest_info g ON b.guest_ref = g.guest_ref WHERE b.room_number=?", (search_text,))
            else:
                messagebox.showerror("Error", "Invalid search criteria")

            rows = cursor.fetchall()

            for row in self.Guest_Details_Table.get_children():
                self.Guest_Details_Table.delete(row)

            for row in rows:
                booking_date = row[4] if row[4] else ""
                departure_date = row[5] if row[5] else ""
                self.Guest_Details_Table.insert("", END, values=(row[0], row[1], row[2], row[3], booking_date, departure_date))

        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

    def show_all_guests(self):
        try:
            cursor = self.conn.cursor()
            cursor.execute("SELECT b.guest_ref, g.name, b.block_name, b.room_number, b.booking_date, b.departure_date FROM booking b INNER JOIN guest_info g ON b.guest_ref = g.guest_ref")
            rows = cursor.fetchall()

            for row in self.Guest_Details_Table.get_children():
                self.Guest_Details_Table.delete(row)

            for row in rows:
                booking_date = row[4] if row[4] else ""
                departure_date = row[5] if row[5] else ""
                self.Guest_Details_Table.insert("", END, values=(row[0], row[1], row[2], row[3], booking_date, departure_date))

        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {str(e)}")

    def create_booking_table(self):
        try:
            cursor = self.conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS booking (
    guest_ref TEXT,
    block_name TEXT,
    room_number INTEGER,
    booking_date DATE,
    departure_date DATE,
    advance_payment TEXT,
    advance_payment_date DATE,
    advance_receipt_no TEXT,
    advance_amount REAL,
    FOREIGN KEY (guest_ref) REFERENCES guest_info(guest_ref)
)
            ''')
            self.conn.commit()
        except Exception as e:
            print(f"An error occurred while creating the 'booking' table: {str(e)}")

if __name__ == "__main__":
    try:
        conn = sqlite3.connect("guest_info.db")
        print("Successfully connected to the database.")
        root = Tk()
        obj = Booking(root, conn)
        root.mainloop()
        conn.close()
        print("Connection closed successfully.")
    except Exception as e:
        print(f"An error occurred: {str(e)}")
